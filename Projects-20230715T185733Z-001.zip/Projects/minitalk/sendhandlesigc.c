/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sendhandlesigc.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/23 13:04:03 by lcruz-ma          #+#    #+#             */
/*   Updated: 2023/03/23 13:10:11 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>

void handler(int num)
{
    write(STDOUT_FILENO, "I won't die!\n", 13);
}

int main()
{
    signal(SIGINT, handler);
    signal(SIGTERM, handler);
    while(1)
    {
        printf("Repeat %d \n", getpid());
        sleep(1);
    }
}
# 42-Cursus-02-Minitalk
The purpose of this project is to code a small data exchange program using UNIX signals.

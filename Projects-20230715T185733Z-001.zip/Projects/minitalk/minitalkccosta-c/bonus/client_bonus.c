/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   client_bonus.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccosta-c <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/01/07 15:42:17 by ccosta-c          #+#    #+#             */
/*   Updated: 2023/01/27 14:40:39 by ccosta-c         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lib_bonus.h"

void	handler_client(char character, int pid)
{
	int	i;

	i = 0;
	while (i < 8)
	{
		if ((character & (0b1 << i)) == 0)
			kill(pid, SIGUSR2);
		else
			kill(pid, SIGUSR1);
		i++;
		usleep(200);
	}
}

void	message_received(int signal)
{
	(void)signal;
	ft_printf("\033[1;32mMESSAGE RECEIVED!\033[0m\n");
}

int	main(int argc, char **argv)
{
	int					i;
	struct sigaction	sms;

	if (argc != 3)
		ft_printf("\033[1;31mThe command is ./client [PID] [MESSAGE]\033[0m\n");
	else
	{
		i = 0;
		sms.sa_handler = &message_received;
		if (sigaction(SIGUSR1, &sms, NULL) == -1)
			ft_printf("Error");
		while (argv[2][i] != '\0')
		{
			handler_client(argv[2][i], ft_atoi(argv[1]));
			i++;
		}
		handler_client('\n', ft_atoi(argv[1]));
		handler_client('\0', ft_atoi(argv[1]));
	}
	return (0);
}

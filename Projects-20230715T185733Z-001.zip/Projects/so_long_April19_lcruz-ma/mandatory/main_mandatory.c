/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_mandatory.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/21 14:03:26 by lcruz-ma          #+#    #+#             */
/*   Updated: 2023/06/14 13:06:34 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	ft_stack_init(t_data *data)
{
	data->x = 0;
	data->y = 0;
	data->fd = 0;
	data->line = 0;
	data->column = 0;
	data->x_p = 0;
	data->y_p = 0;
	data->collect = 0;
	data->moves = 0;
	data->p = 0;
	data->e = 0;
	data->map = 0;
	data->dup_map = 0;
	data->ptr_mlx = 0;
	data->ptr_win = 0;
	data->image_floor = 0;
	data->image_wall = 0;
	data->image_player = 0;
	data->image_collect = 0;
	data->image_exit = 0;
}

void	ft_check_file_map(t_data *data, char *map_name)
{
	data->fd = open(map_name, O_RDONLY);
	if (data->fd < 0)
	{
		ft_printf("Error. Invalid FD!");
		exit(1);
	}
	if (strncmp((map_name + ft_strlen(map_name) - 4), ".ber", 4) != 0)
	{
		ft_printf("Error. Try './so_long (MAP_NAME).ber'!");
		exit(1);
	}
	close(data->fd);
	data->fd = 0;
}

void	ft_file_image(t_data *data, char *argv1)
{
	data->image_floor = mlx_xpm_file_to_image(data->ptr_mlx, FLOOR, &data->x, &data->y);
	data->image_exit = mlx_xpm_file_to_image(data->ptr_mlx, EXIT, &data->x, &data->y);
	data->image_collect = mlx_xpm_file_to_image(data->ptr_mlx, COLLECT, &data->x, &data->y);
	data->image_player = mlx_xpm_file_to_image(data->ptr_mlx, PLAYER, &data->x, &data->y);
	data->image_wall = mlx_xpm_file_to_image(data->ptr_mlx, WALL, &data->x, &data->y);
	ft_map_read(data, argv1);
}

void	ft_map_read(t_data *data, char *argv1)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	data->fd = open(argv1, O_RDONLY);
	data->line = ft_line_count(data);
	close (data->fd);
	data->fd = open(argv1, O_RDONLY);
	data->map = ft_calloc(data->line, sizeof(char *));
	ft_map_fill(data);
	data->ptr_win = mlx_new_window(data->ptr_mlx, ft_length(data->map[0]) * SIZE,
			data->line * SIZE, "so_long");
	if (data->ptr_win == NULL)
	{
		free(data->ptr_win);
		return ;
	}
	ft_fill_window(data, i, j);
	close(data->fd);
}

int	main(int argc, char **argv)
{
	t_data	data;

	if (argc != 2)
	{
		ft_printf("Error. Try './so_long (MAP_FILE).ber'!\n");
		return (0);
	}
	ft_stack_init(&data);
	if (argc == 2)
	{
		ft_check_file_map(&data, argv[1]);
		data.ptr_mlx = mlx_init();
		if (data.ptr_mlx == NULL)
			return (0);
		ft_file_image(&data, argv[1]);
		mlx_hook(data.ptr_win, KeyPress, KeyPressMask, input_handler, &data);
		mlx_hook(data.ptr_win, DestroyNotify, ButtonPressMask, ft_image_destroyer2, &data);
		mlx_loop(data.ptr_mlx);
	}
	return (0);
}

/*int	main(void)
{
	void	*mlx;
	void	*mlx_win;

	mlx = mlx_init();
	mlx_win = mlx_new_window(mlx, 1920, 1080, "Hello World!");
	mlx_loop(mlx);
}*/

/*int	main(void)
{
	void	*img;
	void	*mlx;

	mlx = mlx_init();
	img = mlx_new_image(mlx, 1920, 1080);
}*/


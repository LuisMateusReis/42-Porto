/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/21 14:09:17 by lcruz-ma          #+#    #+#             */
/*   Updated: 2023/05/29 18:09:53 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SO_LONG_H
# define SO_LONG_H

# include "../libft/libft.h"
# include "../minilibx-linux/mlx.h"
# include "../minilibx-linux/mlx_int.h"
# include <unistd.h>
# include <X11/X.h>
# include <fcntl.h>
# include <stdio.h>
# include <stdlib.h>

# define SIZE 40
# define WALL "mandatory/images/WALL.xpm"
# define FLOOR "mandatory/images/FLOOR.xpm"
# define PLAYER "mandatory/images/PLAYER.xpm"
# define COLLECT "mandatory/images/COLLECT.xpm"
# define EXIT "mandatory/images/EXIT.xpm"

typedef struct stack_data
{
	int		x;
	int		y;
	int		fd;
	int		line;
	int		column;
	int		x_p;
	int		y_p;
	int		collect;
	int		moves;
	int		p;
	int		e;
	char	**map;
	char	**dup_map;
	void	*ptr_mlx;
	void	*ptr_win;
	void 	*image_floor;
	void	*image_wall;
	void	*image_player;
	void	*image_collect;
	void	*image_exit;
}				t_data;

void	ft_stack_init(t_data *data);
void	ft_check_file_map(t_data *data, char *map_name);
void	ft_file_image(t_data *data, char *argv1);
void	ft_map_read(t_data *data, char *argv1);

int	ft_line_count(t_data *data);
void	ft_map_fill(t_data *data);
void	ft_lines_check(t_data *data);
int	ft_image_destroyer1(t_data *data);
void	ft_fill_window(t_data *data, int i, int j);

int	ft_image_destroyer2(t_data *data);
void	ft_map_free(t_data *data);
void	ft_columns_check(t_data *data);
void	ft_retangle_check(t_data *data);
int	ft_length(char const *str);

void	ft_letters_check(t_data *data);
void	ft_check_walls(t_data *data);
void	ft_player_coordinates(t_data *data);
void	ft_check_elements(t_data *data);
void	ft_path_check(t_data *data);

void	ft_dup_map(t_data *data);
void	ft_map_free2(t_data *data);
void	ft_put_image(t_data *d, int y, int x, char flag);
int	ft_move_player(t_data *data, int y, int x, char flag);
int	input_handler(int keysym, t_data *data);
#endif

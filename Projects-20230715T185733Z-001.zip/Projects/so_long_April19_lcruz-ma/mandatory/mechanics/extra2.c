/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   extra2.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/15 13:49:10 by lcruz-ma          #+#    #+#             */
/*   Updated: 2023/06/14 13:19:27 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

int	ft_image_destroyer2(t_data *data)
{
	mlx_destroy_image(data->ptr_mlx, data->image_floor);
	mlx_destroy_image(data->ptr_mlx, data->image_wall);
	mlx_destroy_image(data->ptr_mlx, data->image_player);
	mlx_destroy_image(data->ptr_mlx, data->image_exit);
	mlx_destroy_image(data->ptr_mlx, data->image_collect);
	ft_map_free(data);
	mlx_destroy_window(data->ptr_mlx, data->ptr_win);
	mlx_destroy_display(data->ptr_mlx);
	free(data->ptr_mlx);
	exit(0);
}

void	ft_map_free(t_data *data)
{
	int	i;

	i = 0;
	while (data->map[i])
	{
		free(data->map[i]);
		i++;
	}
	free(data->map);
}

void	ft_columns_check(t_data *data)
{
	if (data->column <= 2)
	{
		ft_printf("Error\nYou will need more columns in your map!\n");
		ft_image_destroyer1(data);
		exit (0);
	}
}

void	ft_retangle_check(t_data *data)
{
	int	i;
	int	j;

	i = 0;
	while (i < data->line)
	{
		j = 0;
		while (data->map[i][j])
			j++;
		if (j == data->column)
			i++;
		else
		{
			ft_printf("Error\nThis map isn't a rectangle!\n");
			ft_image_destroyer1(data);
			exit(0);
		}
	}
	ft_letters_check(data);
}

int	ft_length(char const *str)
{
	int	i;

	i = 0;
	while(str[i])
		i++;
	return (i);
}

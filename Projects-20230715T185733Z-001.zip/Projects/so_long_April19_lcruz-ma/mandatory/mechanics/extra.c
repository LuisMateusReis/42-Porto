/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   extra.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/21 15:51:12 by lcruz-ma          #+#    #+#             */
/*   Updated: 2023/05/29 18:29:32 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

int	ft_line_count(t_data *data)
{
	int		i;
	char	*str;

	i = 0;
	while (1)
	{
		str = get_next_line(data->fd);
		if (!str)
			break ;
		free(str);
		i++;
	}
	free (str);
	return (i);
}

void	ft_map_fill(t_data *data)
{
	int		i;
	char	*str;

	i = 0;
	while (i <= data->line)
	{
		str = get_next_line(data->fd);
		if (!str)
		{
			free(str);
			break ;
		}
		data->map[i] = ft_strtrim(str, "\n");
		free (str);
		i++;
	}
	data->column = ft_strlen(data->map[0]);
	ft_lines_check(data);
	ft_retangle_check(data);
}

void	ft_lines_check(t_data *data)
{
	if (data->line <= 2)
	{
		ft_printf("Error\nYou will need more lines in your map!\n");
		ft_image_destroyer1(data);
		exit (0);
	}
	ft_columns_check(data);
}

int	ft_image_destroyer1(t_data *data)
{
	mlx_destroy_image(data->ptr_mlx, data->image_floor);
	mlx_destroy_image(data->ptr_mlx, data->image_wall);
	mlx_destroy_image(data->ptr_mlx, data->image_player);
	mlx_destroy_image(data->ptr_mlx, data->image_exit);
	mlx_destroy_image(data->ptr_mlx, data->image_collect);
	mlx_destroy_display(data->ptr_mlx);
	if (data->map != 0)
		ft_map_free(data);
	free(data->ptr_mlx);
	exit(0);
}

void	ft_fill_window(t_data *data, int i, int j)
{
	while (i < data->line)
	{
		j = 0;
		while (data->map[i][j] != '\n' && data->map[i][j] != '\0')
		{
			if (data->map[i][j] == '1')
				mlx_put_image_to_window(data->ptr_mlx, data->ptr_win,
					data->image_wall, j * SIZE, i * SIZE);
			else if (data->map[i][j] == '0')
				mlx_put_image_to_window(data->ptr_mlx, data->ptr_win,
					data->image_floor, j * SIZE, i * SIZE);
			else if (data->map[i][j] == 'C')
				mlx_put_image_to_window(data->ptr_mlx, data->ptr_win,
					data->image_collect, j * SIZE, i * SIZE);
			else if (data->map[i][j] == 'P')
				mlx_put_image_to_window(data->ptr_mlx, data->ptr_win,
					data->image_player, j * SIZE, i * SIZE);
			else if (data->map[i][j] == 'E')
				mlx_put_image_to_window(data->ptr_mlx, data->ptr_win,
					data->image_exit, j * SIZE, i * SIZE);
			j++;
		}
		i++;
	}
}

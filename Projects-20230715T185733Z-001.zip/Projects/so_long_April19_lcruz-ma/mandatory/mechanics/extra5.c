/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   extra5.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/26 14:42:57 by lcruz-ma          #+#    #+#             */
/*   Updated: 2023/05/29 15:26:29 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

int	ft_flood_fill(t_data *d, char **map, int x, int y)
{
	static int	c;
	static int	e;

	if (y < 0 || x < 0 || y > d->line || x > d->column
		|| map[y][x] == '1' || map[y][x] == 'X')
		return (0);
	if (map[y][x] == 'E')
	{
		e++;
		map[y][x] = 'X';
		return (0);
	}
	if (map[y][x] == 'C')
		c++;
	map[y][x] = 'X';
	ft_flood_fill(d, map, x + 1, y);
	ft_flood_fill(d, map, x - 1, y);
	ft_flood_fill(d, map, x, y + 1);
	ft_flood_fill(d, map, x, y - 1);
	if (e == 1 && c == d->collect)
		return (1);
	else
		return (0);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   extra4.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/15 14:24:28 by lcruz-ma          #+#    #+#             */
/*   Updated: 2023/06/09 16:24:04 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

void	ft_dup_map(t_data *data)
{
	int	i;

	i = 0;
	data->dup_map = ft_calloc(data->line + 1, sizeof(char *));
	while (i < data->line)
	{
		data->dup_map[i] = ft_strdup(data->map[i]);
		i++;
	}
}

void	ft_map_free2(t_data *data)
{
	int	i;

	i = 0;
	while (data->dup_map[i])
	{
		free(data->dup_map[i]);
		i++;
	}
	free(data->dup_map);
}

void	ft_put_image(t_data *d, int y, int x, char flag)
{
	if (flag == 'A')
		mlx_put_image_to_window(d->ptr_mlx, d->ptr_win, d->image_player,
			x * SIZE, y * SIZE);
	else if (flag == 'W')
		mlx_put_image_to_window(d->ptr_mlx, d->ptr_win, d->image_player,
			x * SIZE, y * SIZE);
	else if (flag == 'S')
		mlx_put_image_to_window(d->ptr_mlx, d->ptr_win, d->image_player,
			x * SIZE, y * SIZE);
	else if (flag == 'D')
		mlx_put_image_to_window(d->ptr_mlx, d->ptr_win, d->image_player,
			x * SIZE, y * SIZE);
}

int	ft_move_player(t_data *d, int y, int x, char flag)
{
	if (d->map[y][x] == '0' || d->map[y][x] == 'C')
	{
		mlx_put_image_to_window(d->ptr_mlx, d->ptr_win, d->image_floor,
			d->x_p * SIZE, d->y_p * SIZE);
		ft_put_image(d, y, x, flag);
		if (d->map[y][x] == 'C')
			d->collect -= 1;
		d->map[d->y_p][d->x_p] = '0';
		d->map[y][x] = '0';
		d->y_p = y;
		d->x_p = x;
		d->moves ++;
		return (1);
	}
	else if (d->map[y][x] == 'E' && d->collect == 0)
	{
		ft_printf("Total Moves: %d\n", d->moves + 1);
		ft_image_destroyer2(d);
	}
	return (0);
}

int	input_handler(int keysym, t_data *data)
{
	int	result;

	result = 0;
	if (keysym == 65307)
		ft_image_destroyer1(data);
	if (keysym == 119)
		result = ft_move_player(data, data->y_p - 1, data->x_p, 'W');
	if (keysym == 97)
		result = ft_move_player(data, data->y_p, data->x_p - 1, 'A');
	if (keysym == 115)
		result = ft_move_player(data, data->y_p + 1, data->x_p, 'S');
	if (keysym == 100)
		result = ft_move_player(data, data->y_p, data->x_p + 1, 'D');
	if (result == 1)
		ft_printf("Move number: %d\n", data->moves);
	return (0);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   extra3.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/15 14:05:50 by lcruz-ma          #+#    #+#             */
/*   Updated: 2023/06/14 13:20:20 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

void	ft_letters_check(t_data *data)
{
	int	y;
	int	x;

	y = 0;
	while (y < data->line)
	{
		x = 0;
		while (x < data->column)
		{
			if (data->map[y][x] == '1' || data->map[y][x] == '0' ||
				data->map[y][x] == 'C' || data->map[y][x] == 'P' ||
				data->map[y][x] == 'E')
				x++;
			else
			{
				ft_printf("Error\n Invalid elements in the map\n");
				ft_image_destroyer1(data);
			}
		}
		y++;
	}
	ft_check_walls(data);
}

void	ft_check_walls(t_data *d)
{
	int	i;

	i = 0;
	while (i < d->column)
	{
		if (d->map[0][i] != '1' || d->map[d->line - 1][i] != '1')
		{
			ft_printf("Error\nWall not valid!\n");
			ft_image_destroyer1(d);
		}
		i++;
	}
	i = 1;
	while (i < d->line - 1)
	{
		if (d->map[i][0] != '1' || d->map[i][d->column - 1] != '1')
		{
			ft_printf("Error\nWall not valid!\n");
			ft_image_destroyer1(d);
		}
		i++;
	}
	ft_player_coordinates(d);
}

void	ft_player_coordinates(t_data *data)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (i < data->line)
	{
		j = 0;
		while (data->map[i][j])
		{
			if (data->map[i][j] == 'P')
			{
				data->x_p = j;
				data->y_p = i;
				data->p ++;
			}
			if (data->map[i][j] == 'C')
				data->collect++;
			if (data->map[i][j] == 'E')
				data->e++;
			j++;
		}
		i++;
	}
	ft_check_elements(data);
}

void	ft_check_elements(t_data *data)
{
	if (data->p != 1)
	{
		ft_printf("Error\nWrong number of player elements!\n");
		ft_image_destroyer1(data);
		exit (0);
	}
	else if (data->e != 1)
	{
		ft_printf("Error\nWrong number of exit elements!\n");
		ft_image_destroyer1(data);
		exit (0);
	}
	else if (data->collect <= 0)
	{
		ft_printf("Error\nWrong number of collectible elements!\n");
		ft_image_destroyer1(data);
		exit (0);
	}
	ft_path_check(data);
}

void	ft_path_check(t_data *data)
{
	ft_dup_map(data);
	if (ft_flood_fill(data, data->dup_map, data->x_p, data->y_p) != 1)
	{
		ft_printf("Error\nInvalid Map Path\n", 2);
		ft_map_free2(data);
		ft_image_destroyer1(data);
	}
	else
		ft_map_free2(data);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/10 14:18:10 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/11/10 14:35:33 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strdup(const char *s)
{
	char	*dupl;
	size_t	bsize;

	bsize = (ft_strlen(s) + 1) * sizeof(char);
	dupl = (char *)malloc(bsize);
	if (!dupl)
		return (NULL);
	dupl = (char *)ft_memcpy(dupl, s, bsize);
	return (dupl);
}

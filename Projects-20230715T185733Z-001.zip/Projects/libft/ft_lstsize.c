/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstsize.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/21 12:07:09 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/11/28 17:25:42 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_lstsize(t_list *lst)
{
	int	count;

	count = 0;
	while (lst != NULL)
	{
		count++;
		lst = lst->next;
	}
	return (count);
}
/*
#include <stdio.h>

int	main(void)
{
	t_list	*head;

	head = malloc(sizeof(t_list));
	head->content = (void *)45;
	head->next = NULL;

	t_list	*ptr1;
	ptr1 = NULL;

	t_list	*ptr2;
	t_list	*current;

	ptr2 = malloc(sizeof(t_list));
	ptr2->content = (void *)31;
	current = malloc(sizeof(t_list));
	current->content = (void *)32;
	current->content = NULL;
	ptr2->next = current;
	printf("%d",ft_lstsize(head));
	printf("%d", ft_lstsize(ptr1));
	printf("%d", ft_lstsize(ptr2));
	return (0);
}*/

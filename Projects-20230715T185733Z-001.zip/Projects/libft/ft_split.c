/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/23 17:31:43 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/11/28 17:19:12 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_lenwithoutcs(const char *s, char c)
{
	size_t	len;

	len = 0;
	while (*s)
	{
		if (*s != c)
			len++;
		s++;
	}
	return (len);
}

char	**ft_split(const char *s, char c)
{
	int		i;
	int		j;
	char	**strs;

	i = 0;
	if (!s)
		return (0);
	strs = malloc(sizeof(char *) * (ft_lenwithoutcs(s, c) + 1));
	if (!strs)
		return (0);
	while (*s)
	{
		if (*s != c)
		{
			j = 0;
			while (*s && *s != c && ++j)
				++s;
			strs[i++] = ft_substr(s - j, 0, j);
		}
		else
			++s;
	}
	strs[i] = NULL;
	return (strs);
}

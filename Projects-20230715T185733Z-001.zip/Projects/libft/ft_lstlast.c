/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstlast.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/21 13:25:45 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/11/21 15:15:09 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

t_list	*ft_lstlast(t_list *lst)
{
	if (lst == NULL)
		return (NULL);
	while (lst->next != NULL)
		lst = lst->next;
	return (lst);
}
/*
#include <stdio.h>

int	main(void)
{
	t_list	*head;

	head = malloc(sizeof(t_list));
	head->content = (void *)45;
	head->next = NULL;

	t_list	*ptr2;
	t_list	*current;

	ptr2 = malloc(sizeof(t_list));
	ptr2->content = (void *)31;
	current = malloc(sizeof(t_list));
	current->content = (void *)32;
	current->content = NULL;
	ptr2->next = current;
	printf("%d\n", ft_lstsize(head));
	printf("%p\n", head);
	printf("%p\n", ft_lstlast(head));
	printf("%d", ft_lstsize(ptr2));

	return (0);
}*/

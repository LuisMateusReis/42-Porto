/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/17 12:21:42 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/11/28 14:28:37 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

unsigned int	numberdigits(int n)
{
	int	i;

	i = 0;
	if (n <= 0)
		i++;
	while (n != 0)
	{
		n /= 10;
		i++;
	}
	return (i);
}

char	*ft_itoa(int n)
{
	char			*str;
	unsigned int	size;

	size = numberdigits(n);
	str = (char *)malloc((size + 1) * sizeof(char));
	if (!str)
		return (NULL);
	str[size] = '\0';
	if (n < 0)
		str[0] = '-';
	if (n == 0)
		str[0] = '0';
	while (n)
	{
		if (n > 0)
			str[--size] = (n % 10) + '0';
		else
			str[--size] = (n % 10) * -1 + '0';
		n /= 10;
	}
	return (str);
}
/*
#include <stdio.h>

int	main(void)
{
	printf("%d\n", numberdigits(5));
	printf("%d\n", numberdigits(-5));
	printf("%d\n", numberdigits(10));
	printf("%d\n", numberdigits(0));
	printf("%d\n", numberdigits(-0));
	printf("%d\n", numberdigits(-10));
	printf("%d\n", numberdigits(-453));
	printf("%s\n", ft_itoa(-2147483648));
	printf("%s\n", ft_itoa(-976543210));
	printf("%s\n", ft_itoa(-10));
	printf("%s\n", ft_itoa(-9));
	printf("%s\n", ft_itoa(-1));
	printf("%s\n", ft_itoa(0));
	printf("%s\n", ft_itoa(-0));
	printf("%s\n", ft_itoa(1));
	printf("%s\n", ft_itoa(9));
	printf("%s\n", ft_itoa(10));
	printf("%s\n", ft_itoa(9753210));
	printf("%s", ft_itoa(125689));
	printf("%s", ft_itoa(-623));
	return (0);
}*/

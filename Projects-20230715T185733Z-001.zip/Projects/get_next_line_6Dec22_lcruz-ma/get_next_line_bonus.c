/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_bonus.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/15 13:14:23 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/12/15 13:58:41 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line_bonus.h"

static char	*ft_line_plus(int fd, char *buffer, char *line_plus)
{
	int		num_bytes;
	char	*cpy;

	num_bytes = 1;
	while (num_bytes != 0)
	{
		num_bytes = read(fd, buffer, BUFFER_SIZE);
		if (num_bytes == -1)
			return (0);
		if (num_bytes == 0)
			break ;
		buffer[num_bytes] = '\0';
		if (!line_plus)
		{
			line_plus = malloc(sizeof(char));
			line_plus[0] = '\0';
		}
		cpy = line_plus;
		line_plus = ft_strjoin(cpy, buffer);
		free(cpy);
		if (ft_strchr(buffer, '\n'))
			break ;
	}
	return (line_plus);
}

static char	*ft_line(char *line)
{
	char	*line_plus;
	int		counter;

	counter = 0;
	while (line[counter] != '\n' && line[counter] != '\0')
		counter++;
	if (line[counter] == '\0')
		return (0);
	line_plus = ft_substr(line, counter + 1, ft_strlen(line) - counter);
	if (line_plus[0] == '\0')
	{
		free(line_plus);
		line_plus = 0;
	}
	line[counter + 1] = '\0';
	return (line_plus);
}

char	*get_next_line(int fd)
{
	static char	*line_plus[1024];
	char		*line;
	char		*buffer;

	if (BUFFER_SIZE <= 0 || fd < 0 || fd >= 1025)
		return (0);
	buffer = malloc(sizeof(char) * (BUFFER_SIZE + 1));
	if (!buffer)
		return (0);
	line = ft_line_plus(fd, buffer, line_plus[fd]);
	free(buffer);
	if (!line)
	{
		free(line_plus[fd]);
		return (0);
	}
	line_plus[fd] = ft_line(line);
	return (line);
}

#include <fcntl.h>
#include <stdio.h>

int main(void)
{
	int fd;
	char *line;

	fd = open("text.txt", O_RDONLY);
	//printf("%s", get_next_line(fd));
	while (1)
	{
		line = get_next_line(fd);
		if (!line)
		{
			printf("FOI NULO");
			free(line);
			break;
		}
		printf("%s", line);
		free(line);
	}
	free(line);
	return (0);
}
/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_char_b.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/30 13:34:44 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/12/06 12:54:48 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_put_char_b(int c)
{
	return (write(1, &c, 1));
}

/*
#include <stdio.h>

int	main(void)
{
	ft_put_char_b('a');
	return (0);
}*/

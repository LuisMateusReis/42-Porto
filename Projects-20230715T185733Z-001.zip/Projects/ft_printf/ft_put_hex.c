/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_hex.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/02 12:29:13 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/12/06 15:53:48 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_put_hex(unsigned int num, char c)
{
	int				len;
	unsigned int	numcpy;

	len = 0;
	numcpy = num;
	if (numcpy == 0)
		return (write(1, "0", 1));
	while (numcpy != 0)
	{
		numcpy /= 16;
		len++;
	}
	if (num >= 16)
	{
		ft_put_hex(num / 16, c);
		ft_put_hex(num % 16, c);
	}
	if (num <= 9)
		ft_put_char_b(num + '0');
	if (num >= 10 && num <= 15 && c == 'x')
		ft_put_char_b(num - 10 + 'a');
	else if (num >= 10 && num <= 15 && c == 'X')
		ft_put_char_b(num - 10 + 'A');
	return (len);
}
/*
int	main(void)
{
	unsigned int hex = 45632123;

	return (0);
}
*/

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/29 14:48:38 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/12/06 16:01:22 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_writeformat(va_list ap, char const c)
{
	int	num;

	num = 0;
	if (c == 'c')
		num += ft_put_char_b(va_arg(ap, int));
	else if (c == 's')
		num += ft_put_str_b(va_arg(ap, char *));
	else if (c == 'p')
		num += ft_put_ptr_hex(va_arg(ap, unsigned long long));
	else if (c == 'd' || c == 'i')
		num += ft_put_int(va_arg(ap, int));
	else if (c == 'u')
		num += ft_put_uns_dec(va_arg(ap, unsigned int));
	else if (c == 'x' || c == 'X')
		num += ft_put_hex(va_arg(ap, unsigned int), c);
	else if (c == '%')
		num += write(1, "%", 1);
	return (num);
}

int	ft_printf(const char *str, ...)
{
	va_list	ap;
	int		i;
	int		num;

	if (!str)
		return (-1);
	i = 0;
	num = 0;
	va_start(ap, str);
	while (str[i])
	{
		if (str[i] != '%')
			num += write(1, &str[i], 1);
		else if (str[i] == '%')
			num += ft_writeformat(ap, str[i++ + 1]);
		i++;
	}
	va_end(ap);
	return (num);
}

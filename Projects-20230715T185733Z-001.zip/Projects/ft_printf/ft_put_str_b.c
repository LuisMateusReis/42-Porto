/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_str_b.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/30 13:18:27 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/12/06 15:11:37 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_put_str_b(char *str)
{
	unsigned int	i;

	i = 0;
	if (str == (char *) NULL)
		i += write(1, "(null)", 6);
	else
	{
		while (str[i])
			write(1, &str[i++], 1);
	}
	return (i);
}

/*
#include <stdio.h>

int	main(void)
{
	printf("%d\n", printf("%s", (char *)NULL));
	printf("%d\n", ft_putstr1((char *)NULL));
	return (0);
}*/

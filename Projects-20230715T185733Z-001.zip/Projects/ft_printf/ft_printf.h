/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/29 15:56:41 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/12/06 15:53:48 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H

# include <stdarg.h>
# include <unistd.h>

int	ft_printf(const char *str, ...);
int	ft_put_char_b(int c);
int	ft_put_str_b(char *str);
int	ft_put_ptr_hex(unsigned long long address);
int	ft_put_int(int num);
int	ft_put_uns_dec(unsigned int num);
int	ft_put_hex(unsigned int num, char c);

#endif

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_libft.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/04 12:35:29 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/11/10 15:17:17 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# include "libft.h"
# include <stdio.h>
# include <ctype.h>
# include <string.h>
# include <strings.h>
# include <bsd/string.h>

int	main(void)
{
	const char	a = '0';
	const char	b = '9';
	const char	c1 = 0;	
	const char	c2 = 127;
	const char	c3 = -128;
	const char	c4 = 32;
	const char	d = 'a';
	const char	e = 'z';
	const char	f = 'A';
	const char	g = 'Z';
	const char	h = '^';
	const char	l = '\0';
	const char	str1[] = "AA";
	const char	str2[] = "";
	
	//Testing int ft_isalpha(int c) function
	
	printf("Beggining of testing int ft_isalpha(int c) function.\n");
	printf("Testing if the input is alphabetical: != 0 if it is, == 0 if it isn't.\n\n");
	printf("Tested isalpha(%c), Original %d, User %d.\n", a, isalpha(a), ft_isalpha(a));
	printf("Tested isalpha(%c), Original %d, User %d.\n", c1, isalpha(c1), ft_isalpha(c1));
	printf("Tested isalpha(%c), Original %d, User %d.\n", d, isalpha(d), ft_isalpha(d));
	printf("Tested isalpha(%c), Original %d, User %d.\n", e, isalpha(e), ft_isalpha(e));
	printf("Tested isalpha(%c), Original %d, User %d.\n", f, isalpha(f), ft_isalpha(f));
	printf("Tested isalpha(%c), Original %d, User %d.\n\n", g, isalpha(g), ft_isalpha(g));
	
	//Test int ft_isdigit(int c) function
	
	printf("Beggining of testing int ft_isdigit(int c) function.\n");
	printf("Testing if the input is a digit: != 0 if it is, == 0 if it isn't.\n\n");
	printf("Tested isdigit(%c), Original %d, User %d.\n", a, isdigit(a), ft_isdigit(a));
	printf("Tested isdigit(%c), Original %d, User %d.\n", b, isdigit(b), ft_isdigit(b));
	printf("Tested isdigit(%d), Original %d, User %d.\n", c1, isdigit(c1), ft_isdigit(c1));
	printf("Tested isdigit(%c), Original %d, User %d.\n\n", d, isdigit(d), ft_isdigit(d));
	
	//Testing int ft_isalnum(int c) function
	
	printf("Beggining of testing int ft_isalnum(int c) function.\n");
	printf("Testing if the input is a alphabetical character or a digit: != 0 if it is, == 0 if it isn't.\n\n");
	printf("Tested isalnum(%c), Original %d, User %d.\n", a, isalnum(a), ft_isalnum(a));
	printf("Tested isalnum(%c), Original %d, User %d.\n", b, isalnum(b), ft_isalnum(b));
	printf("Tested isalnum(%d), Original %d, User %d.\n", c1, isalnum(c1), ft_isalnum(c1));
	printf("Tested isalnum(%c), Original %d, User %d.\n", d, isalnum(d), ft_isalnum(d));
	printf("Tested isalnum(%c), Original %d, User %d.\n", e, isalnum(e), ft_isalnum(e));
	printf("Tested isalnum(%c), Original %d, User %d.\n", f, isalnum(f), ft_isalnum(f));
	printf("Tested isalnum(%c), Original %d, User %d.\n\n", g, isalnum(g), ft_isalnum(g));
	
	//Testing int ft_isascii(int c)
	
	printf("Beggining of testing int ft_isascii(int c) function. \n");
	printf("Testing if the input is an ascii value: != 0 if it is, == 0 if it isn't.\n\n");
	printf("Tested isascii(%d), Original %d, User %d.\n", c1, isascii(c1), ft_isascii(c1));
	printf("Tested isascii(%d), Original %d, User %d.\n", c2, isascii(c2), ft_isascii(c2));
	printf("Tested isascii(%d), Original %d, User %d.\n\n", c3, isascii(c3), ft_isascii(c3));
	
	//Testing int ft_isprint(int c)
	
	printf("Beggining of testing int ft_isprint(int c) function. \n");
	printf("Testing if the input is a printable character: != 0 if it is, == 0 if it isn't.\n\n");
	printf("Tested isprint(%d), Original %d, User %d.\n", c1, isprint(c1), ft_isprint(c1));
	printf("Tested isprint(%d), Original %d, User %d.\n", c2, isprint(c2), ft_isprint(c2));
	printf("Tested isprint(%d), Original %d, User %d.\n\n", c4, isprint(c4), ft_isprint(c4));
	
	//Testing size_t ft_strlen(const char *str)
	
	printf("Beggining of testing size_t ft_strlen(const char *str) function. \n");
	printf("Testing string length up to but not including the terminating null character.\n\n");
	printf("Tested string \"%s\", Original %zu, User %zu.\n", str1, strlen(str1), ft_strlen(str1));
	printf("Tested empty string, Original %zu, User %zu.\n", strlen(str2), ft_strlen(str2));
	printf("Tested '%c', Original %zu, User %zu.\n\n", d, strlen(&d), ft_strlen(&d));
	
	//Testing void *ft_memset(void *str, int c, size_t n)
		//Testar char *
	printf("Beggining of testing void *ft_memset(void *str, int c, size_t n) function. \n");
	printf("Testing if it copies the character c (an unsigned char) to the first n characters of the string pointed to, by str.\n\n");
	
	char	str4[] = "abcdef";
	char	str5[] = "abcdef";
	printf("Tested (char *)memset(\"%s\", '%c', (size_t)0), ", str4, h);
	printf("Original \"%s\", User \"%s\".\n", (char *)memset(str4, 94, (size_t)0), (char *)ft_memset(str5, 94, (size_t)0));
	char	str6[] = "abcdef";
	char	str7[] = "abcdef";
	printf("Tested (char *)memset(\"%s\", '%c', 1), ", str6, h);
	printf("Original \"%s\", User \"%s\".\n", (char *)memset(str6, 94, 1), (char *)ft_memset(str7, 94, 1));
	
	char	str8[] = "abcdef";
	char	str9[] = "abcdef";
	printf("Tested (char *)memset(\"%s\", '%c', 6), ", str8, h);
	printf("Original \"%s\", User \"%s\".\n", (char *)memset(str8, 94, 6), (char *)ft_memset(str9, 94, 6));
	
	char	str10[9] = "abcdef";
	char	str11[9] = "abcdef";
	printf("Tested (char *)memset(\"%s\", '%c', 7), ", str10, h);
	printf("Original \"%s\", User \"%s\".\n", (char *)memset(str10, 94, 7), (char *)ft_memset(str11, 94, 7));
	
	printf("Tested (char *)memset(\"%s\", '%c', (size_t)0), ", "", h);
	printf("Original \"%s\", User \"%s\".\n", (char *)memset("", 94, (size_t)0), (char *)ft_memset("", 94, (size_t)0));
	
		//Testar int *
	
	int	arrayint1[] = {1,2};
	int	arrayint2[] = {1,2};
	printf("Tested (int *)memset({%d,%d}, 3, 0), ", arrayint1[0], arrayint1[1]);
	printf("Original {%d,%d}, User {%d,%d}.\n", ((int *)memset(arrayint1, 3, (size_t)0))[0], ((int *)memset(arrayint1, 3, (size_t)0))[1], ((int *)ft_memset(arrayint2, 3, (size_t)0))[0], ((int *)ft_memset(arrayint2, 3, (size_t)0))[1]);
	
	int	arrayint3[] = {1,2};
	int	arrayint4[] = {1,2};
	printf("Tested (int *)memset({%d,%d}, 3, 1), ", arrayint3[0], arrayint3[1]);
	printf("Original {%d,%d}, User {%d,%d}.\n\n", ((int *)memset(arrayint3, 3, 1))[0], ((int *)memset(arrayint3, 3, 1))[1], ((int *)ft_memset(arrayint4, 3, 1))[0], ((int *)ft_memset(arrayint4, 3, 1))[1]);
	
	//Testing void bzero(void *s, size_t n)
	
	printf("Beggining of testing void bzero(void *s, size_t n) function. \n");
	printf("Testing if the  function erases the data in the n bytes of the memory starting at the location pointed to by s, by writing zeros (bytes containing '\\0') to that area.\n\n");
	
	char	str12[] = "abc";
	char	str13[] = "abc";
	printf("Tested bzero(\"%s\", (size_t)0), ", str12);
	bzero(str12, (size_t)0);
	ft_bzero(str13, (size_t)0);
	printf("Original \"%s\", User \"%s\". \n", str12, str13);
	
	char	str14[] = "abc";
	char	str15[] = "abc";
	printf("Tested bzero(\"%s\", 1), ", str14);
	bzero(str14, 1);
	ft_bzero(str15,1);
	printf("Original %c%c%c%c, User %c%c%c%c. \n\n", str14[0], str14[1], str14[2], str14[3], str15[0], str15[1], str15[2], str15[3]);
	
	//Testing void *memcpy(void *dest, const void *src, size_t n)
	printf("Beggining of testing void *memcpy(void *dest, const void *src, size_t n). \n");
	printf("Testing if the  function copies n characters from memory area src to memory area dest.\n\n");
	
	char	dest1[] = "abcd";
	char	dest2[] = "abcd";
	char	src1[] = "123";
	printf("Tested *memcpy(\"%s\", \"%s\", 0), ", dest1, src1);
	memcpy(dest1, src1, 0);
	ft_memcpy(dest1, src1, 0);
	printf("Real dest \"%s\", User dest \"%s\".\n", dest1, dest2);
	
	char	dest3[] = "abcd";
	char	dest4[] = "abcd";
	printf("Tested *memcpy(\"%s\", \"%s\", 1), ", dest3, src1);
	memcpy(dest3, src1, 1);
	ft_memcpy(dest4, src1, 1);
	printf("Real \"%s\", User \"%s\". \n", dest3, dest4);
	
	char	dest5[] = "abcd";
	char	dest6[] = "abcd";
	printf("Tested *memcpy(\"%s\", \"%s\", 3), ", dest5, src1);
	memcpy(dest5, src1, 3);
	ft_memcpy(dest6, src1, 3);
	printf("Real dest \"%s\", User dest \"%s\".\n", dest5, dest6);
	
	char	dest7[] = "abcd";
	char	dest8[] = "abcd";
	printf("Tested *memcpy(\"%s\", \"%s\", 4), ", dest7, src1);
	memcpy(dest7, src1, 4);
	ft_memcpy(dest8, src1, 4);
	printf("Real dest \"%s\", User dest \"%s\".\n", dest7, dest8);
	
	char	src3[] = "";
	char	dest11[] = "abcd";
	char	dest12[] = "abcd";
	printf("Tested *memcpy(\"%s\", \"%s\", 1), ", dest11, src3);
	memcpy(dest11, src3, 1);
	ft_memcpy(dest12, src3, 1);
	printf("Real dest \"%s\", User dest \"%s\".\n", dest11, dest12);
	
	char	dest9[] = "";
	char	dest10[] = "";
	printf("Tested *memcpy(\"%s\", \"%s\", 1), ", dest9, src1);
	memcpy(dest9, src1, 1);
	ft_memcpy(dest10, src1, 1);
	printf("Real dest \"%s\", User dest \"%s\".\n", dest9, dest10);
	
	char	dest13[] = "";
	char	dest14[] = "";
	printf("Tested *memcpy(\"%s\", \"%s\", 0), ", dest13, src3);
	memcpy(dest13, src3, 0);
	ft_memcpy(dest14, src3, 0);
	printf("Real dest \"%s\", User dest \"%s\".\n", dest13, dest14);
	
	char	dest15[] = "";
	char	dest16[] = "";
	printf("Tested *memcpy(\"%s\", \"%s\", 1), ", dest15, src3);
	memcpy(dest15, src3, 1);
	ft_memcpy(dest16, src3, 1);
	printf("Real dest \"%s\", User dest \"%s\".\n", dest15, dest16);
	
	printf("\n");
	
	//Testing void *ft_memmove(void *dest, const void *src, size_t n)
	
	printf("Beggining of testing void *ft_memmove(void *dest, const void *src, size_t n). \n");
	printf("Testing if the  function copies n bytes from memory area src to memory area dest.  The memory areas may overlap: copying takes place as though the bytes in src are first copied into a temporary array that does not overlap src or dest, and the bytes are then copied from the temporary array to dest.\n\n");
	
	//Testing size_t ft_strlcpy(char *dst, const char *src, size_t size);
	
	char	src4[] = "abc";
	char	dest17[] = "1234";
	char	dest18[] = "1234";
	printf("Tested ft_strlcpy(\"%s\", \"%s\", 0), ", dest17, src4);
	printf("Real return %zu, User return %zu, ", strlcpy(dest17, src4, 0), ft_strlcpy(dest18, src4, 0));
	printf("Real dst \"%s\", User dst \"%s\". \n", dest17, dest18);
	
	char	dest19[] = "1234";
	char	dest20[] = "1234";
	printf("Tested ft_strlcpy(\"%s\", \"%s\", 1), ", dest19, src4);
	printf("Real return %zu, User return %zu, ", strlcpy(dest19, src4, 1), ft_strlcpy(dest20, src4, 1));
	printf("Real dst \"%s\", User dst \"%s\". \n", dest19, dest20);
	
	char	dest21[] = "1234";
	char	dest22[] = "1234";
	printf("Tested ft_strlcpy(\"%s\", \"%s\", 2), ", dest21, src4);
	printf("Real return %zu, User return %zu, ", strlcpy(dest21, src4, 2), ft_strlcpy(dest22, src4, 2));
	printf("Real dst \"%s\", User dst \"%s\". \n", dest21, dest22);
	
	char	dest23[] = "1234";
	char	dest24[] = "1234";
	printf("Tested ft_strlcpy(\"%s\", \"%s\", 4), ", dest23, src4);
	printf("Real return %zu, User return %zu, ", strlcpy(dest23, src4, 4), ft_strlcpy(dest24, src4, 4));
	printf("Real dst \"%s\", User dst \"%s\". \n", dest23, dest24);
	
	char	dest25[] = "1234";
	char	dest26[] = "1234";
	printf("Tested ft_strlcpy(\"%s\", \"%s\", 5), ", dest25, src4);
	printf("Real return %zu, User return %zu, ", strlcpy(dest25, src4, 5), ft_strlcpy(dest26, src4, 5));
	printf("Real dst \"%s\", User dst \"%s\". \n", dest25, dest26);
	
	printf("\n");
	
	//Testing size_t ft_strlcat(char *dst, const char *src, size_t size);
	
	printf("Beggining of testing size_t ft_strlcat(char *dst, const char *src, size_t size). \n");
	printf("Testing if the function append one string onto the end of the other. \n\n");
	
	char	src5[] = "Ola";
	char	dest27[] = "Hello";
	char	dest28[] = "Hello";

	printf("Tested ft_strlcat(\"%s\", \"%s\", 4), ", dest27, src5);
	printf("User return %zu, User dst \"%s\", ", ft_strlcat(dest28, src5, 4), dest28);
	printf("Real return %zu, Real dst \"%s\". \n", strlcat(dest27, src5, 4), dest27);
	
	char	dest29[] = "Hello";
	char	dest30[] = "Hello";

	printf("Tested ft_strlcat(\"%s\", \"%s\", 5), ", dest29, src5);
	printf("User return %zu, User dst \"%s\", ", ft_strlcat(dest30, src5, 5), dest30);
	printf("Real return %zu, Real dst \"%s\". \n", strlcat(dest29, src5, 5), dest29);
	
	char	dest31[] = "Hello";
	char	dest32[] = "Hello";

	printf("Tested ft_strlcat(\"%s\", \"%s\", 6), ", dest31, src5);
	printf("User return %zu, User dst \"%s\", ", ft_strlcat(dest32, src5, 6), dest32);
	printf("Real return %zu, Real dst \"%s\". \n", strlcat(dest31, src5, 6), dest31);
	
	char	dest33[] = "Hello";
	char	dest34[] = "Hello";

	printf("Tested ft_strlcat(\"%s\", \"%s\", 7), ", dest33, src5);
	printf("User return %zu, User dst \"%s\", ", ft_strlcat(dest34, src5, 7), dest34);
	printf("Real return %zu, Real dst \"%s\". \n", strlcat(dest33, src5, 7), dest33);
	
	char	dest35[] = "Hello";
	char	dest36[] = "Hello";

	printf("Tested ft_strlcat(\"%s\", \"%s\", 9), ", dest35, src5);
	printf("User return %zu, User dst \"%s\", ", ft_strlcat(dest36, src5, 9), dest36);
	printf("Real return %zu, Real dst \"%s\". \n", strlcat(dest35, src5, 9), dest35);
	
	char	dest37[] = "Hello";
	char	dest38[] = "Hello";

	printf("Tested ft_strlcat(\"%s\", \"%s\", 10), ", dest37, src5);
	printf("User return %zu, User dst \"%s\", ", ft_strlcat(dest38, src5, 10), dest38);
	printf("Real return %zu, Real dst \"%s\". \n", strlcat(dest37, src5, 10), dest37);
	
	//Testing int ft_toupper(int c)
	
	printf("Beggining of testing int ft_toupper(int c). \n");
	printf("Testing if c is a lowercase letter, ft_toupper() returns its uppercase equivalent, if an uppercase representation exists in the current locale.  Otherwise, it returns  c. \n\n");
	
	printf("Tested ft_toupper(char 0), Real return %d, User return %d.\n", toupper(c1), ft_toupper(c1));
	printf("Tested ft_toupper('%c'), Real return %d, User return %d.\n", d, toupper(d), ft_toupper(d));
	printf("Tested ft_toupper('%c'), Real return %d, User return %d.\n", e, toupper(e), ft_toupper(e));
	printf("Tested ft_toupper('%c'), Real return %d, User return %d.\n\n", f, toupper(f), ft_toupper(f));
	
	//Testing int ft_tolower(int c)
	
	printf("Beggining of testing int ft_tolower(int c). \n");
	printf("Testing if function takes an uppercase alphabet and convert it to a lowercase character. If the arguments passed to the ft_tolower() function is other than an uppercase alphabet, it returns the same character that is passed to the function. \n\n");
	
	printf("Tested ft_toupper(char 0), Real return %d, User return %d.\n", tolower(c1), ft_tolower(c1));
	printf("Tested ft_toupper('%c'), Real return %d, User return %d.\n", d, tolower(d), ft_tolower(d));
	printf("Tested ft_toupper('%c'), Real return %d, User return %d.\n", g, tolower(g), ft_tolower(g));
	printf("Tested ft_toupper('%c'), Real return %d, User return %d.\n\n", f, tolower(f), ft_tolower(f));
	
	//Testing char *ft_strchr(const char *s, int c)
	
	printf("Beggining of testing char *ft_strchr(const char *s, int c). \n");
	printf("Testing if function returns a pointer to the first occurrence of the character c in the string s. return a pointer to the matched character or NULL if the character is not found.  The terminating null byte is considered part of the string, so that if c is specified as '\\0', these functions return a pointer to the terminator. \n\n");
	
	const char	s1[] = "abcdef";
	char	d3 = 99;
	
	printf("Tested ft_strchr(\"%s\", '%c'), Real return \"%s\", User return \"%s\". \n", s1, d, strchr(s1, d), ft_strchr(s1, d)); 
	printf("Tested ft_strchr(\"%s\", '%c'), Real return \"%s\", User return \"%s\". \n", s1, d3, strchr(s1, d3), ft_strchr(s1, d3));
	printf("Tested ft_strchr(\"%s\", '\\0'), Real return \"%s\", User return \"%s\", ", s1, strchr(s1, l), ft_strchr(s1, l));
	if (*strchr(s1, l) == '\0')
		printf("Real return '\\0', ");
	else
		printf("Real return is not '\\0'");
	if (*ft_strchr(s1, l) == '\0')
		printf("User return '\\0'. \n");
	else
		printf("User return is not '\\0'");
	printf("Tested ft_strchr(\"%s\", '%c'), Real return %s, User return %s. \n\n", str1, d, strchr(str1, d), ft_strchr(str1, d));
		
	//Testing char *ft_strrchr(const char *s, int c)
	
	printf("Beggining of testing char *ft_strrchr(const char *s, int c). \n");
	printf("Testing if function returns a pointer to the last occurrence of the character c in the string s. Returns a pointer to the matched character or NULL if the character is not found. The terminating null byte is considered part of the string, so that if c is specified as '\\0', these functions return a pointer to the terminator.  \n\n");
	
	printf("Tested ft_strrchr(\"%s\", '%c'), Real return \"%s\", User return \"%s\". \n", s1, d, strrchr(s1, d), ft_strrchr(s1, d)); 
	printf("Tested ft_strrchr(\"%s\", '%c'), Real return \"%s\", User return \"%s\". \n", s1, d3, strrchr(s1, d3), ft_strrchr(s1, d3));
	printf("Tested ft_strrchr(\"%s\", '\\0'), Real return \"%s\", User return \"%s\", ", s1, strrchr(s1, l), ft_strrchr(s1, l));
	if (*strrchr(s1, l) == '\0')
		printf("Real return '\\0', ");
	else
		printf("Real return is not '\\0', ");
	if (*ft_strrchr(s1, l) == '\0')
		printf("User return '\\0'. \n");
	else
		printf("User return is not '\\0'. \n");
	printf("Tested ft_strrchr(\"%s\", '%c'), Real return %s, User return %s. \n", str1, d, strrchr(str1, d), ft_strrchr(str1, d));

	const char	s2[] = "cbcdcf";
	
	printf("Tested ft_strrchr(\"%s\", '%c'), Real return \"%s\", User return \"%s\". \n\n", s2, d3, strrchr(s2, d3), ft_strrchr(s2, d3));
	
	//Testing int strncmp(const char *s1, const char *s2, size_t n)
	
	printf("Beggining of testing int strncmp(const char *s1, const char *s2, size_t n). \n");
	printf("Testing if function compares the two strings s1 and s2. It returns an integer less than, equal to, or greater than zero if s1 is found, respectively, to be less than, to match, or be greater than s2. The ft_strncmp() function only compares the first (at most) n bytes of s1 and s2.   \n\n");
	
	const char	s3[] = "abc";
	const char	s4[] = "abca";
	
	printf("Tested ft_strncmp(\"%s\", \"%s\", 3), Real return %d, User return %d. \n", s3, s3, strncmp(s3, s3, 3), ft_strncmp(s3, s3, 3));
	printf("Tested ft_strncmp(\"%s\", \"%s\", 4), Real return %d, User return %d. \n", s3, s3, strncmp(s3, s3, 4), ft_strncmp(s3, s3, 4));
	printf("Tested ft_strncmp(\"%s\", \"%s\", 3), Real return %d, User return %d. \n", s3, s4, strncmp(s3, s4, 3), ft_strncmp(s3, s4, 3));
	printf("Tested ft_strncmp(\"%s\", \"%s\", 4), Real return %d, User return %d. \n", s3, s4, strncmp(s3, s4, 4), ft_strncmp(s3, s4, 4));
	printf("Tested ft_strncmp(\"%s\", \"%s\", 4), Real return %d, User return %d. \n", s4, s3, strncmp(s4, s3, 4), ft_strncmp(s4, s3, 4));
	printf("Tested ft_strncmp(\"%s\", \"%s\", 2), Real return %d, User return %d. \n\n", str2, str2, strncmp(str2, str2, 2), ft_strncmp(str2, str2, 2));
	
	//Testing void *ft_memchr(const void *s, int c, size_t n)
	
	printf("Beggining of testing void *ft_memchr(const void *s, int c, size_t n). \n");
	printf("Testing if function scans the initial n bytes of the memory area pointed to by s for the first instance of c.  Both c and the bytes of the memory area pointed to by s are interpreted as unsigned char. Return a pointer to the matching byte or NULL if the character does not occur in the given memory area.  \n\n");
	
	const char	s5[] = "abb";
	const char	d1 = 'b';
	const char	d2 = 'c';
	
	printf("Tested ft_memchr(\"%s\", '%c', 4), Real return \"%s\", User return \"%s\". \n", s5, d, (char *)memchr(s5, d, 4), (char *)ft_memchr(s5, d, 4));
	printf("Tested ft_memchr(\"%s\", '%c', 4), Real return \"%s\", User return \"%s\". \n", s5, d1, (char *)memchr(s5, d1, 4), (char *)ft_memchr(s5, d1, 4));
	printf("Tested ft_memchr(\"%s\", '%c', 4), Real return \"%s\", User return \"%s\". \n", s5, d1, (char *)memchr(s5, d1, 4), (char *)ft_memchr(s5, d1, 4));
	printf("Tested ft_memchr(\"%s\", '%c', 0), ", s5, d1);
	if ((char *)memchr(s5, d1, 0) == NULL)
		printf("Real return is NULL, ");
	else
		printf("Real return is not NULL, ");
	if ((char *)ft_memchr(s5, d1, 0) == NULL)
		printf("User return is NULL. \n");
	else
		printf("User return is not NULL,  \n");
	printf("Tested ft_memchr(\"%s\", '%c', 4), Real return %s, User return %s. \n", s5, d2, (char *)memchr(s5, d2, 4), (char *)ft_memchr(s5, d2, 4));
	printf("Tested ft_memchr(\"%s\", '\\0', 4), Real return %s, User return %s, ", s5,  (char *)memchr(s5, l, 4), (char *)ft_memchr(s5, l, 4));
	if (((char *)memchr(s5, l, 4))[0] == '\0')
		printf("Real return '\\0', ");
	else
		printf("Real return is not '\\0', ");
	if (((char *)ft_memchr(s5, l, 4))[0] == '\0')
		printf("User return '\\0'. \n\n");
	else
		printf("User return not '\\0'. \n\n");

	//Testing int ft_memcmp(const void *s1, const void *s2, size_t n)
	
	printf("Beggining of testing int ft_memcmp(const void *s1, const void *s2, size_t n). \n");
	printf("Testing if function compares the first n bytes (each interpreted as unsigned char) of the memory areas s1 and s2. returns an integer less than, equal to, or greater than zero if the first n bytes of s1 is found, respectively, to be less than, to match, or be greater than the first n bytes of s2. For a nonzero return value, the sign is determined by the sign of the difference between the first pair of bytes (interpreted as unsigned char) that differ in s1 and s2. If n is zero, the return value is zero.  \n\n");
	
	printf("Tested ft_memcmp(\"%s\", \"%s\", 3), Real return %d, User return %d. \n", s3, s3, memcmp(s3, s3, 3), ft_memcmp(s3, s3, 3));
	printf("Tested ft_memcmp(\"%s\", \"%s\", 4), Real return %d, User return %d. \n", s3, s3, memcmp(s3, s3, 4), ft_memcmp(s3, s3, 4));
	printf("Tested ft_memcmp(\"%s\", \"%s\", 3), Real return %d, User return %d. \n", s3, s4, memcmp(s3, s4, 3), ft_memcmp(s3, s4, 3));
	printf("Tested ft_memcmp(\"%s\", \"%s\", 4), Real return %d, User return %d. \n", s3, s4, memcmp(s3, s4, 4), ft_memcmp(s3, s4, 4));
	printf("Tested ft_memcmp(\"%s\", \"%s\", 4), Real return %d, User return %d. \n\n", s4, s3, memcmp(s4, s3, 4), ft_memcmp(s4, s3, 4));
	
	//Testing char *strnstr(const char *big, const char *little, size_t len)
	
	printf("Beggining of testing char *strnstr(const char *big, const char *little, size_t len). \n");
	printf("Testing if function locates the first occurrence of the null-terminated string little in the null-terminated string big. If little is an empty string, big is returned; if little occurs nowhere in big, NULL is returned; otherwise a pointer to the first character of the first occurrence of little is returned. \n\n");
	
	const char *largestring = "Foo Bar Baz";
	const char *smallstring = "Bar";

	printf("Tested ft_strnstr(\"%s\", \"%s\", 6), Real return %s, User return %s. \n", largestring, smallstring, strnstr(largestring, smallstring, 6), ft_strnstr(largestring, smallstring, 6));
	printf("Tested ft_strnstr(\"%s\", \"%s\", 7), Real return \"%s\", User return \"%s\". \n\n", largestring, smallstring, strnstr(largestring, smallstring, 7), ft_strnstr(largestring, smallstring, 7));
	
	//Testing int ft_atoi(const char *nptr)
	
	printf("Beggining of testing int ft_atoi(const char *nptr). \n");
	printf("Testing if function converts the initial portion of the string pointed to by nptr to int. First only 9 to 13 or 32, after only one of - or +, after only digits until the search ends. \n\n");
	
	const char	atoi1[] = "\t \v+1234abc";
	const char	atoi2[] = "\t \v-4321abc";
	const char	atoi3[] = "\t- 1234cba";
	const char	atoi4[] = "\t-0234cba";
	
	printf("Tested ft_atoi(\"%s\"), Real return %d, User return %d. \n", atoi1, atoi(atoi1), ft_atoi(atoi1));
	printf("Tested ft_atoi(\"%s\"), Real return %d, User return %d. \n", atoi2, atoi(atoi2), ft_atoi(atoi2));
	printf("Tested ft_atoi(\"%s\"), Real return %d, User return %d. \n", atoi3, atoi(atoi3), ft_atoi(atoi3));
	printf("Tested ft_atoi(\"%s\"), Real return %d, User return %d. \n\n", atoi4, atoi(atoi4), ft_atoi(atoi4));
	
	//Testing void *ft_calloc(size_t nmemb, size_t size)
	
	printf("Beggining of testing void *ft_calloc(size_t nmemb, size_t size). \n");
	printf("Testing if function allocates memory for an array of nmemb elements of size bytes each and returns a pointer to the allocated memory. The memory is set to zero. If nmemb or size is 0, then calloc() returns either NULL, or a unique pointer value that can later be successfully passed to free(). The malloc() and calloc() functions return a pointer to the allocated memory that is suitably aligned for any kind of variable. On error, these functions return NULL. NULL may also be returned by a successful call to malloc() with a size of zero, or by a successful call to calloc() with nmemb or size equal to zero. \n\n");
	
	const char	s7[] = {'\0', '\0', '\0'};
	const char	s8[] ={'\0', '2', '\0'};
	
	printf("Tested memcmp({'\\0', '\\0', '\\0'}, (char *)calloc(3,1), 3), returned %d. \n", memcmp(s7, (char *)calloc(3,1), 3));
	 printf("Tested memcmp({'\\0', '\\0', '\\0'}, (char *)ft_calloc(3,1), 3), returned %d. \n", memcmp(s7, (char *)ft_calloc(3,1), 3));
	 printf("Tested memcmp({'\\0', '2', '\\0'}, (char *)calloc(3,1), 3), returned %d. \n", memcmp(s8, (char *)calloc(3,1), 3));
	 printf("Tested memcmp({'\\0', '2', '\\0'}, (char *)ft_calloc(3,1), 3), returned %d. \n\n", memcmp(s8, (char *)ft_calloc(3,1), 3));
	
	//Testing char *ft_strdup(const char *s)
	
	printf("Beggining of testing char *ft_strdup(const char *s). \n");
	printf("Testing if function returns a pointer to a new string which is a duplicate of the string s. Memory for the new string is obtained with malloc(3), and can be freed with free(3). The strdup() function returns a pointer to the duplicated string, or NULL if insufficient memory was available. \n\n");
	
	const char	s6[] = "Hey";
	
	printf("Tested ft_strdup(\"%s\"), Real returned \"%s\", User returned \"%s\". \n", s6, strdup(s6), ft_strdup(s6));
	printf("Tested memcmp(\"%s\", strdup(\"%s\"), %d), Real returned %d, and memcmp(\"%s\", ft_strdup(\"%s\"), %d), User returned %d, both should be 0. \n", s6, s6, (int)ft_strlen(s6) + 1, memcmp(s6, strdup(s6), (int)ft_strlen(s6) + 1), s6, s6, (int)ft_strlen(s6) + 1, memcmp(s6, ft_strdup(s6),(int)ft_strlen(s6) + 1));
	printf("Tested ft_memcmp(\"%s\", strdup(\"%s\"), %d), Real returned %d, and memcmp(\"%s\", ft_strdup(\"%s\"), %d), User returned %d, both should be 0. \n\n", s6, s6, (int)ft_strlen(s6) + 1, ft_memcmp(s6, strdup(s6), (int)ft_strlen(s6) + 1), s6, s6, (int)ft_strlen(s6) + 1, ft_memcmp(s6, ft_strdup(s6),(int)ft_strlen(s6) + 1));
	
	//Testing char *ft_substr(char const *s, unsigned int start, size_t len)
	
	printf("Beggining of testing char *ft_substr(char const *s, unsigned int start, size_t len). \n");
	printf("Testing if function allocates (with malloc(3)) and returns a substring from the string ’s’. The substring begins at index ’start’ and is of maximum size ’len’. \n\n");
	
	const char	s9[] = "abcdef";
	
	printf("Tested ft_substr(\"%s\", %d, %d), returned \"%s\", ft_strlen da return string %ld. \n", s9, 0, 0, ft_substr(s9, 0, 0), ft_strlen(ft_substr(s9, 0, 0)));
	printf("Tested ft_substr(\"%s\", %d, %d), returned \"%s\", ft_strlen da return string %ld. \n", s9, 0, 1, ft_substr(s9, 0, 1), ft_strlen(ft_substr(s9, 0, 1)));
	printf("Tested ft_substr(\"%s\", %d, %d), returned \"%s\", ft_strlen da return string %ld. \n", s9, 1, 0, ft_substr(s9, 1, 0), ft_strlen(ft_substr(s9, 1, 0)));
	printf("Tested ft_substr(\"%s\", %d, %d), returned \"%s\", ft_strlen da return string %ld. \n", s9, 1, 1, ft_substr(s9, 1, 1), ft_strlen(ft_substr(s9, 1, 1)));
	printf("Tested ft_substr(\"%s\", %d, %d), returned \"%s\", ft_strlen da return string %ld. \n", s9, 1, 2, ft_substr(s9, 1, 2), ft_strlen(ft_substr(s9, 1, 2)));
	printf("Tested ft_substr(\"%s\", %d, %d), returned \"%s\", ft_strlen da return string %ld. \n", s9, 5, 1, ft_substr(s9, 5, 1), ft_strlen(ft_substr(s9, 5, 1)));
	printf("Tested ft_substr(\"%s\", %d, %d), returned \"%s\", ft_strlen da return string %ld. \n", s9, 5, 2, ft_substr(s9, 5, 2), ft_strlen(ft_substr(s9, 5, 2)));
	
	//Testing char *ft_strjoin(char const *s1, char const *s2)
	
	printf("Beggining of testing char *ft_strjoin(char const *s1, char const *s2). \n");
	printf("Testing if function allocates (with malloc(3)) and returns a new string, which is the result of the concatenation of ’s1’ and ’s2’. \n\n");
	
	const char	s10[] = "abc";
	const char	s11[] = "def";
	
	printf("Tested ft_strjoin(\"%s\", \"%s\"), returned \"%s\". \n", s10, s11, ft_strjoin(s10, s11));
	
	//Testing 
	
	//the end of main
	
	return (0);
}

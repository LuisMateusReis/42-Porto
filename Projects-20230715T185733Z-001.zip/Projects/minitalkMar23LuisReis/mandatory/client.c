/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   client.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/13 13:10:05 by lcruz-ma          #+#    #+#             */
/*   Updated: 2023/04/14 11:46:46 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minitalk.h"

void	handle_client(char letter, int pid)
{
	int	k;

	k = 0;
	while (k <= 7)
	{
		if ((letter & (0b1 << k)) == 0)
			kill(pid, SIGUSR2);
		else
			kill(pid, SIGUSR1);
		k++;
		usleep(400);
	}
}

int	main(int argc, char **argv)
{
	int	j;

	if (argc != 3)
		ft_printf("Write './client [PID] [String]'!");
	else
	{
		j = 0;
		while (argv[2][j])
			handle_client(argv[2][j++], ft_atoi(argv[1]));
	}
	return (0);
}

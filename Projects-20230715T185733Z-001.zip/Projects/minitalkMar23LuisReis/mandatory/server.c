/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   server.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/28 14:59:58 by lcruz-ma          #+#    #+#             */
/*   Updated: 2023/04/17 14:16:37 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minitalk.h"

void	handle_server(int sig)
{
	static unsigned char	letter;
	static int				i;

	if (sig == SIGUSR1)
		letter |= (0b1 << i);
	i++;
	if (i == 8)
	{
		write(1, &letter, 1);
		i = 0;
		letter = 0;
	}
}

int	main(int argc, char **argv)
{
	struct sigaction	sa;

	(void)argv;
	sa.sa_handler = &handle_server;
	if (argc != 1)
		ft_printf("Try: './server'\n");
	ft_printf("Server PID = %d\n", getpid());
	sigaction(SIGUSR1, &sa, NULL);
	sigaction(SIGUSR2, &sa, NULL);
	while (1)
		pause();
	return (0);
}

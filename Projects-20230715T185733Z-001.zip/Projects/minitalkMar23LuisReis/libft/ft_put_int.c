/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_int.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/02 13:21:04 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/12/06 15:06:26 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	len_int(int num)
{
	int	len;

	len = 0;
	if (num == 0)
		return (1);
	if (num < 0)
		len++;
	while (num != 0)
	{
		num /= 10;
		len++;
	}
	return (len);
}

int	ft_put_int(int num)
{
	int	len;

	len = len_int(num);
	if (num == -2147483648)
		return (write(1, "-2147483648", 11));
	if (num < 0)
	{
		write(1, "-", 1);
		num = -num;
	}
	if (num >= 10)
	{
		ft_put_int(num / 10);
		ft_put_int(num % 10);
	}
	else
		ft_put_char_b(num + '0');
	return (len);
}
/*
#include <stdio.h>

int	main(void)
{
	printf("%d\n", ft_put_int(0));
	printf("%d", ft_put_int(-5));
	return (0);
}
*/

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_ptr_hex.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/30 15:23:30 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/12/02 17:15:20 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_put_ptr_hex_b(unsigned long long address)
{
	int					len;
	unsigned long long	addresscpy;

	len = 0;
	addresscpy = address;
	while (addresscpy != 0)
	{
		addresscpy /= 16;
		len++;
	}
	if (address >= 16)
	{
		ft_put_ptr_hex_b(address / 16);
		ft_put_ptr_hex_b(address % 16);
	}
	else if (address <= 9)
		ft_put_char_b(address + '0');
	else
		ft_put_char_b(address - 10 + 'a');
	return (len);
}

int	ft_put_ptr_hex(unsigned long long address)
{
	int	len;

	len = 0;
	if (address == 0)
		len += write(1, "(nil)", 5);
	else
	{
		len += write(1, "0x", 2);
		len += ft_put_ptr_hex_b(address);
	}
	return (len);
}

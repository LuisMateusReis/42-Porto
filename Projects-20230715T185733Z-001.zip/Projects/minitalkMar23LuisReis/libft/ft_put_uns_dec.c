/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_uns_dec.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/02 13:20:26 by lcruz-ma          #+#    #+#             */
/*   Updated: 2022/12/06 15:52:55 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_put_uns_dec(unsigned int num)
{
	int				len;
	unsigned int	numcpy;

	len = 0;
	numcpy = num;
	if (num == 0)
		return (write(1, "0", 1));
	while (numcpy != 0)
	{
		numcpy /= 10;
		len++;
	}
	if (num >= 10)
	{
		ft_put_uns_dec(num / 10);
		ft_put_uns_dec(num % 10);
	}
	else
		ft_put_char_b(num + '0');
	return (len);
}
/*
#include <stdio.h>

int	main(void)
{
	unsigned int num;
	num = 4294967295;
	ft_put_uns_dec(num);
	return (0);
}*/

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   server_bonus.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/06 16:19:34 by lcruz-ma          #+#    #+#             */
/*   Updated: 2023/04/14 11:25:15 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minitalk_bonus.h"

void	server_handle(int sig, siginfo_t *info, void *ucontext)
{
	static unsigned char	letter;
	static int				j;

	(void)ucontext;
	if (sig == SIGUSR1)
		letter |= 0b1 << j;
	j++;
	if (j == 8)
	{
		if (letter == '\0')
			kill(info->si_pid, SIGUSR1);
		write(1, &letter, 1);
		j = 0;
		letter = 0;
	}
}

int	main(int argc, char **argv)
{
	struct sigaction	sa;

	(void)argv;
	sa.sa_sigaction = &server_handle;
	sa.sa_flags = SA_SIGINFO;
	if (argc != 1)
		ft_printf("Just write './server'!");
	ft_printf("Server PID = %d\n", getpid());
	sigaction(SIGUSR1, &sa, NULL);
	sigaction(SIGUSR2, &sa, NULL);
	while (1)
		pause();
	return (0);
}

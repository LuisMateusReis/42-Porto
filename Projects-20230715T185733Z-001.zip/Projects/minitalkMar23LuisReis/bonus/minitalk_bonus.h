/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minitalk_bonus.h                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcruz-ma <lcruz-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/28 14:35:00 by lcruz-ma          #+#    #+#             */
/*   Updated: 2023/04/14 11:45:34 by lcruz-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINITALK_BONUS_H
# define MINITALK_BONUS_H

# include "../libft/libft.h"

# include <signal.h>
# include <unistd.h>
# include <string.h>
# include <stdlib.h>

void	client_handle(char letter, int pid);
void	message_back(int sig);
void	server_handle(int sig, siginfo_t *info, void *ucontext);

#endif
